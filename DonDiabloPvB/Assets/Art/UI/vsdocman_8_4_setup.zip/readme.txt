VSdocman 8.4 - Code Commenter and Generator of Class Documentation for C# and VB .NET


1. OVERVIEW

VSdocman is a tool for commenting and the quick automatic generation of class documentation from your C# and VB .NET source code files. It is ideal tool for you if you create .NET component, control, application, smart device or web site (ASP .NET) projects.

VSdocman parses the Visual Basic .NET and C# projects and automatically creates MSDN-like API documentation with the table of contents, index, topics, cross-references, IntelliSense and F1 context sensitive help. 

With VSdocman you can:
 - Add and use XML comments in your source code.
 - Take advantage of its sophisticated WYSIWYG comment editor which helps you write your XML comments.
 - Easily insert tables, lists, pictures, links and other formatting directly in your source code.
 - Generate professional documentation in multiple and localizable output formats - HTML, CHM, Help2, MS Help Viewer, Docx, PDF, XML.
 - Fully integrate generated help into the VS help system.
 - Generate documentation in command line mode.
 - Easily deploy the documentation to target computers.

VSdocman works as an extension with:
 - Visual Studio 2017 - all editions
 - Visual Studio 2015 - all editions except for Express edition
 - Visual Studio 2013 - all editions except for Express edition
 - Visual Studio 2012 - all editions except for Express edition



2. BENEFITS

 - You will get your API reference with just single mouse click. In large projects, VSdocman will save many days of boring tedious work. 
 - All in one . You can create complex comments, generate documentation and then deploy and register it.
 - Professional documentation of your components can be created in seconds for your customers or co-developers.
 - Consistency. All changes in the code are automatically reflected in newly generated documentation.
 - Documentation in various formats can be generated with a few mouse clicks and you have documentation in all supported formats in a few minutes.
 - Efficient communication within the team, especially when source control is used. Every programmer comments his part of the code. Everybody in the team can then make documentation and easily understand that code and get on-line help.
 - The source code is precisely commented and looks nice.



3. INSTALLATION

Before installing VSdocman uninstall any previous versions of VSdocman installed on your computer. Then just unzip installation package and run installation MSI file. VSdocman will be installed. After that it should be accessible in Visual Studio's Extensions list. Detailed help is also available.



4. UNINSTALLATION

Go to "Control Panel" -> "Programs and Features" and select VSdocman. All work is done automatically.



5. TRIAL VERSION

Trial 14 day version of VSdocman comes with these limitations:
 - warning message is displayed every time a new documentation is compiled
 - you are not allowed to distribute generated documentation
 - the "watermark" text is inserted in generated documentation after the trial period expires



6. HOW TO REGISTER

Anyone may use this software during a trial period of 14 days.
The 14 day trial only counts the days when the program is actually used, not calendar days.
Following this trial period of 14 days or less, if you wish to continue 
to use VSdocman, you MUST register (buy). When you buy VSdocman, you become
registered user.

Registered users will get:
 - full product license, which is perpetual and it will never expire
 - free email support for the period of one year
 - free updates within one year of any registered purchase
 - discounts on non-free update (renewal)

You can register at http://www.helixoft.com via secure connection using Share-it service.
Share-it is well-known, leading shareware commerce company.
The registration is quick and easy. Usually, you will have the full version in a while.

We accept Mastercard/Eurocard, Visa, American Express, and Diner's Club online.
Alternatively, we support PayPal, bank transfer /wire transfer, we accept Checks and Money Orders
through postal mail. Corporate users may place a purchase order.

Immediately after the payment is accepted you receive an e-mail with your registration code. Download and install the trial version of VSdocman. Go to VSdocman main window and press REGISTER button to enter the code. If the code is valid, the trial version becomes a full version immediately.

Please visit http://www.helixoft.com/vsdocman/buy-or-upgrade-vsdocman.html.



7. CHANGES

In version 8.4
 1. NEW: Added new supported platforms whose versions you can specify and display in the generated documentation. These are: .NET Core, .NET Standard, Xamarin.Android, Xamarin.iOS and Xamarin.Mac.
 2. NEW: You can now specify what value will be displayed for constants and enums in the generated documentation. For example, if you have a constant const int C = 2+2, you can display the evaluated expression result "4", as before. But this may be time consuming if you have hundreds of constants or enum items. So you can also choose to display the original expression "2+2" or nothing.
 3. CHANGE: The specified supported platforms (such as Windows 10) are no longer listed in generated html_msdn2017 and chm_msdn2017 output formats. Only the frameworks versions are listed. If you don't want to include the platforms in other output formats, just leave the "Platforms shown in documentation" field empty on the Output - Platforms & Frameworks page of project properties.
 4. FIX: Generation or registration of Docx, PDF, XML and MS Help Viewer output formats failed, if there was an invalid XML character used. This could happen for example in the syntax section. If you had a constant such as "const char ACK = (char)0x6;" then VSdocman generated the 0x6 ASCII character in the syntax section. This character is not allowed in the intermediate XML files.

In version 8.3
 1. NEW: Added F# declaration of a member in the generated Syntax section. Useful, if your class library is consumed by an F# client.
 2. CHANGE: Generic types, inherited and extension methods in the Methods list are listed in C# syntax instead of the unfriendly cref syntax. For example, IEnumerable<T> instead of IEnumerable`1.
 3. CHANGE: Inserted comments that were automatically inherited from referenced projects or assemblies had normalized links with prefixes. For example, <see cref="T:System.String"/>. While this was correct, IntelliSense didn't work for such links in XML comments. Now the prefixes are not inserted, for example, <see cref="System.String"/>.
 4. CHANGE: A single <para>...</para> block is no longer generated if it's the only paragraph in an XML comment section. This may happen if you had multiple paragraphs and then you deleted all except the one.
 5. FIX: The full-text search in HTML outputs didn't work if the search term contained a dot, for example "MyNamespace.MyClass".
 6. FIX: Applying a bulleted or a numbered list in the Exceptions in the WYSIWYG comment editor has caused that entire Exceptions section was lost in then XML comment.
 7. FIX: When using the comment editor in non-WYSIWYG mode, changes in user-defined fields were not saved to the edited XML comment.
 8. FIX: The method comment was not inherited from a referenced DLL, if the method had parameters of a generic constructed type, e.g. MyOverridenMethod(Ilist<string> x).
 9. FIX: Some unwanted methods from referenced DLLs were listed as inherited in the Methods list. For example, static methods were listed, such as Object.ReferenceEquals. Or both shadowed and shadowing methods were listed. For example, if you have your own class that inherits from the Exception class, there were two methods listed - Object.GetType and Exception.GetType. Moreover, these methods could be listed also in other unrelated classes.
10. FIX: Some unwanted extension methods were listed in the Extension Methods list. For example, if your class implemented IList<String>, the Average(this IEnumerable<Double>) extension method was incorrectly listed too.
11. FIX: Sometimes, not all member descriptions from referenced DLLs were found. For example, System.Linq.Enumerable.Aggregate methods listed in the Extension Methods list had no summary in .NET 4.0 projects.

In version 8.2
 1. NEW: VSdocman XML comments can be inserted by typing triple /// or '''. This is disabled by default and can be enabled in VSdocman Options > Comments > General. When enabled, the VSdocman XML comments are inserted instead of the default Visual Studio XML comments when you type /// or '''.
 2. CHANGE: Removed the "Show $EOL$ as new line. Write new line as $EOL$" comment editor option. It has been obsolete for very long time.
 3. FIX: Installing VSdocman 8.x over an older version didn't uninstall the existing version in some cases. This happened, if there was an existing installation of VSdocman 7.6 or older and it was installed per user (Just me). The older versions allowed to be installed for "Just me" or "Everyone". If a previous version wasn't uninstalled, VSdocman didn't work correctly, for example the comment editor was empty, with just "aa" text.
 4. FIX: If VSdocman was opened while the solution was still loading, there could be some problems. VSdocman now waits until the solution is loaded.
 5. FIX: Missing comments were not inherited during compilation (whether from overridden or from implemented members) if "Compile Solution to Single Documentation" was executed.
 6. FIX: If there was a type (e.g. a class) that had no namespace, Visual Studio could crash during documentation compilation. This happened if a type was not inside namespace block in C#, or if it was not inside Namespace block in VB .NET and no Root namespace was defined at the project level. Such types are listed under <default> namespace now.
 7. FIX: If a type, e.g. a class, was excluded with <compilewhen> comment element, its members such as methods and properties were still included in the documentation. They were not available in TOC, but they could be visible in Index.
 8. FIX: If the cursor was on a field or a constant, but not directly on the field name, adding an XML comment or opening the comment editor was done for the parent class instead for the field.
 9. FIX: In the comment editor, when a link was pasted, unwanted <u> and <font color=...> tags were added for the link text.
10. FIX: In the comment editor, when a link was pasted from outside, e.g. from a web page, it was not recognized as a link and only a plain text was created.

In version 8.1
 1. NEW: Added support for .NET Core and .NET Standard projects in Visual Studio 2017.
 2. NEW: The generated documentation shows the return type of a method return value or a property and field value, similarly as it's been shown for method parameters.
 3. NEW: Added syntax highlighting for VSdocman output templates (.vbdt files). You only need to edit the output templates if you want to customize the look and feel of your generated documentation. You can now do it directly in Visual Studio with highlighted macros and comments. See <VSdocman folder>\Templates\Vbdt editing\readme.txt for more details.
 4. NEW: Added ability to generate an improved Index in CHM output formats. Such index allows for better context help invocation from external applications. See Viewing and Deploying Documentation > View and Deploy CHM Documentation page in VSdocman help for more details.
 5. CHANGE: The link selector in the Comment editor no longer generates <see> links with a prefix, e.g. T:System.String. This way the Intellisense will work fine for such links in VS code editor.
 6. CHANGE: The links generated in the default comments (e.g. after Add XML comment for constructor) no longer contain a prefix, e.g. T:System.String. This way the Intellisense will work fine for such links in VS code editor. Moreover, the links are created in the short format, e.g. <see cref="System.String"/> instead of longer <see cref="System.String">String</see>. You can apply these new options by pressing Reset button in VSdocman Options. You can backup your current options with the Export button first.
 7. CHANGE: Indexers in C# (properties with parameters in VB .NET) were always listed as 'this[...]' in generated TOC and member list tables. Now, this is changed to Item(...), or to the value of the System.Runtime.CompilerServices.IndexerName attribute, if this attribute is applied or to the property name, if it is a VB property.
 8. CHANGE: Previously, it was possible to create more than two columns only at the time when a table was created in WYSIWYG comment editor. The "Insert column" menu item is no longer disabled if a table has 2 or more columns so you can add a column at any time now.
 9. FIX: Smarter resolving of incomplete cref links. The search is performed also in all parent namespaces/types of the current type. For example, the link cref="Class1" in A.B.C.D.Class2.Class3 will be correctly resolved to A.B.Class1.

In version 8.0
 1. NEW: Added support for Visual Studio 2017.
 2. NEW: Added MSDN 2017 HTML and CHM output formats for generated documentation. They have newer look, list of members is located on a class page and all overloaded members are directly accessible from the TOC and members list.
 3. NEW: Added PDF output format for generated documentation. MS Office 2010 or newer is required for the PDF creation.
 4. NEW: Added /devenvPath parameter for VSdocmanCmdLine.exe utility. It replaces /vs in case of VS 2017.
 5. CHANGE: Removed support for VS 2005, 2008 and 2010. VSdocman now works only with VS 2012 and newer.
 6. CHANGE: Removed RTF and Help&Manual documentation output formats. They were obsolete. Please use Docx instead of RTF.
 7. CHANGE: Better detection of the active project. If there is no project selected in Solution explorer (e.g. the solution is selected), then the active document, if any, is used to get the project. This mechanism is used when you open VSdocman window. On the other hand, if you open the comment editor, the project of the active document is preferred to the one selected in Solution explorer. This project is used in Add/edit link dialog to show the project members.
 8. CHANGE: Simplified licensing mechanism. The purchased license is not bound to VSdocman major version anymore. The registration key now works with any VSdocman version released before the end of the free update period, which is normally one year after the purchase. In simple words, you'll get free updates for the period of one year. After that time, you can keep using the last updated version forever, because the license is perpetual.
 9. CHANGE: Sometimes, the command line compilation of documentation was significantly slower than from VSdocman GUI. They are equally fast now.
10. FIX: In C#, if a class contained an indexer defined in a shortcut form (e.g. public string this[long id] => "abc";), VSdocman threw an exception during documentation compilation.
11. FIX: In VS 2015, if the cursor was inside XML comments of a type (class, enum, ...) and the type had an attribute, the "Comment Editor" operation from the context menu didn't work.
12. FIX: Slow Select/Deselect All files on Project Properties pane, Code Members - Files page. With several hundreds of files (e.g. in a web application), it could take several minutes. Now it's a few seconds.
13. FIX: If there was no .NET 2.0 or 3.5 installed, the .NET 3.5 installation prompt might be displayed during generation of documentation.

In version 7.6
 1. NEW: Added the option to display namespaces with their short names (just the last name part) in the TOC and "Namespaces" table. By default they are listed with their full names. You can now suppress it with the setting in the project properties, not accessible from GUI. Just open .vsdoc file for the project or solution and change the value of the "VBdocman_ListNamespacesWithShortNames" key from 0 to -1.
 2. CHANGE: Improved the startup time of any initial operation with VSdocman (open VSdocman, Add comment, open comment editor, ...) in a large VS solution with a large number of projects.
 3. FIX: Improved inheriting of comments from implemented methods in an implemented interface.
 4. FIX: Explicit <see> links to members that were not explicitly declared in the code, but only inherited, were not generated correctly. An example of such link could be the <see cref="MyClass.ToString"/> link which should point to Object.ToString.
 5. FIX: If the cref attribute in the <exception>, <seealso> and <permission> comment tags didn't contain a full name (e.g. shortened Exception instead of  System.Exception), an incorrect link was generated.
 6. FIX: The WYSIWYG comment editor generated incorrect color value when you selected a text color. If you selected a named color, the color name was generated instead of expected hex value. For example color="red" instead of color="#FF0000". Such colors were ignored in generated documentation.
 7. FIX: Code attributes were taken only from a single partial declaration of a class, interface or structure. If there were other attributes specified in other partial declarations, they were ignored. This way, for example, the ObsoleteAttribute could be ignored in partial classes.
 8. FIX: If a project was removed or renamed in VS solution, and then you made any changes in VSdocman's Profile Manager, these changes were not saved.
 9. FIX: In very rare cases, the command line utility VSdocmanCmdLine.exe could exit with the error code 1 (Visual Studio was not found.) with the additional exception info: COMException (0x80080005). This is usually caused by a temporary high CPU or memory load. Everything usually works on the next execution. So we added the new optional /retryOnCpuBusy COUNT;INTERVAL parameter for the VSdocmanCmdLine.exe which allows you to automatically retry the operation in this situation.

In version 7.5
 1. CHANGE: The Profile manager window is resizable now. It's useful when you have a large solution with many projects.
 2. FIX: Improved font and size scaling of some VSdocman windows on high DPI screens.
 3. FIX: Reloading of a project or a solution file in Visual Studio (e.g. csproj, vbproj, sln) could prevent VSdocman from correctly reading the project properties. Visual Studio restart was required. The reloading usually� happens after updating from source code control or when a file was modified outside of Visual Studio.
 4. FIX: Sometimes, changes in project properties were not saved, especially when dealing with multiple settings profiles. Pressing the OK button in the VSdocman window did nothing.
 5. FIX: Wrong display of warnings in some cases. For example, false "dead link" warnings could appear if conditional compilation of documentation was active. Or some "dead link" warnings were not displayed in very rare cases.

In version 7.4
 1. FIX: Generic interfaces and delegates with covariant and contravariant type parameters were handled incorrectly. Such type parameters are defined with "in" or "out" keywords. For example, "interface IVariant<out T1, in T2>" in C# or "Interface IVariant(Of Out T1, In T2)" in VB .NET. VSdocman generated incorrect XML comments and created wrong documentation for these interfaces and delegates.
 2. FIX: Some changes in a project or a solution were occasionally not reflected by VSdocman, only after Visual Studio restart.  For example, if you added a project into a solution, VSdocman didn't compile documentation for it - it did nothing. Or if you added a reference to a project, it was not used to generate the correct links in the documentation.
 3. FIX: If a project contained references to .winmd files, the references were ignored. Such references are typical e.g. for Universal Windows projects, where they are used via NuGet packages and SDK references. The issue caused that links to Windows Runtime classes (e.g. Windows.UI.Xaml.Controls.Page) didn't work, members and comments were not inherited from them and the inheritance hierarchy was incomplete.
 4. FIX: If a project didn't contain references to the framework assemblies (e.g. mscorlib) directly, but via NuGet package (e.g. Universal Windows projects), VSdocman couldn't retrieve XML comments from such assemblies. The issue caused that some comments couldn't be inherited or that summaries of some inherited methods (e.g. ReferenceEquals) were not shown.
 5. FIX: In some very rare cases, when compiling from command line, the VSdocmanCmdLine.exe process was not closed after successful compilation.

In version 7.3
 1. NEW: Added complete traditional Chinese translation for generated documentation. Just select zh-TW as the language in the output options.
 2. NEW: You can specify topics version for the MS Help Viewer format. See VSdocman's help, Viewing and Deploying Documentation - View and Deploy MS Help Viewer Documentation - Topic Versions in MS Help Viewer Documentation page.
 3. CHANGE: In web site projects without a project file (not web applications), the $(ProjectDir) macro in the output options has a different value. Previously it was the directory constructed from <SOLUTION_FOLDER>\<WEBSITE_NAME>. Now it points just to <SOLUTION_FOLDER>. So if you have a web site (not a web application with a project file) and you specified the Output folder as $(ProjectDir)VSdoc, you need to change it to $(ProjectDir)<WEBSITE_NAME>\VSdoc, where <WEBSITE_NAME> is the name of your web site project.
 4. FIX: The links that contained an ampersand (e.g. <see href="http://www.helixoft.com/index?x=1&y=2"/>) were generated incorrectly.
 5. FIX: The link to the parent namespace was not generated in a code member topic, if the namespace was a root namespace in the project.
 6. FIX: In VB .NET, external methods defined with DllImport attribute instead of Declare statement were not recognized as external.
 7. FIX: Links to external methods (defined with DllImport attribute) were not generated correctly.
 8. FIX: If an event in VB .NET was defined with an explicit generic delegate, e.g. Public Event TextChanged As EventHandler(Of TextChangedEventArgs), the syntax section in documentation was generated incorrectly.
 9. FIX: If a method in a class implemented a method in an interface, the comment for a method was incorrectly inherited if the interface contained multiple method overloads, i.e. methods with the same name but different parameters. This happened when you for example clicked "Add XML comment" for the method in the class.
10. FIX: The blank lines inside a <code> tag that were inserted in the comment editor were not included in the XML comment.
 
In version 7.2
 1. NEW: Added support for new ASP .NET 5 web applications (*.xproj) in VS 2015.
 2. FIX: Namespaces were incorrectly shown at the top TOC level in generated MS Help Viewer format. The problem occurred only in 7.x versions.
 3. FIX: The comment editor produced a damaged comment if it contained a <seealso> tag with a text containing < > & characters. The same applied to <exception> and <permission> tags if they contained these characters in their cref attribute. Now the characters are correctly escaped with &lt; &gt; &amp; and no failure occurs.
 4. FIX: If you selected the text that contained < > & characters in the comment editor and applied inline code style to it (<c> tag), these characters were removed.
 5. FIX: Dead links are no longer displayed as an error text in Docx output format.

In version 7.1

 1. NEW: Statistics of compiled topics (classes, methods, ...) is displayed when the compilation is finished.
 2. NEW: Added complete Chinese translation for generated documentation. Just select zh-CN as the language in the output options.
 3. NEW: You can specify the following additional frameworks to be listed as supported: .NET Framework Client Profile, Portable Class Library, .NET for Windows Store apps and Others.
 4. CHANGE: The CHM compiler that is used for compiling to CHM format is no longer bundled with VSdocman installer. The utility is a part of free HTML Help Workshop from Microsoft that you need to download and install. There's a chance that it is already installed on your system. Check your VSdocman Options - Miscellanous - Environment page.
 5. CHANGE: Improved Help&Manual output. Generated H&M project contained a lot of conditional text, especially due to HxS links. This caused very slow loading and compilation. Since HxS (VS 2005/2008 help format) is no longer used as a common format, all HxS links were converted to web links and the conditional text was removed. This means that, for example, in HxS documentation, the link to System.String now points to online MSDN instead of local MSDN. Large H&M projects are  much more reliable now.
 6. FIX: When the documentation title contained some Unicode characters (e.g. Chinese), then CHM compilation could fail on some systems, probably those with non-English OS.

In version 7.0

 1. NEW: Support for VS 2014 and VS 2014 help system.
 2. NEW: You can easily copy project properties from one project to other projects. There's a new "Copy" button on the left panel of the VSdocman project properties window. You can select which properties will be copied and to which project(s).
 3. NEW: Solution-wide common properties. They are used when you execute "Compile Solution to Single Documentation". They are saved inside a solution profile. You can edit them by clicking on the project name at the top of Project Properties in VSdocman and select SOLUTION-WIDE PROPERTIES.
 4. NEW: You can create and edit XML comments even in a shared project (.shproj), for example in Universal Apps.
 5. NEW: Enabled Ctrl+A in "Edit custom topic source" window and in "View source" tab in the comment editor.
 6. CHANGE: The concept of a "base project" when executing "Compile Solution to Single Documentation" is no longer used. The solution-wide common properties are used instead. You can select which common properties will override the properties from individual projects. This allows you for better flexibility. As a consequence, the /baseProject parameter is no longer supported in command line mode. If you already used "base project" before, you can easily copy its properties to the solution-wide common properties. In VS, select the project that served as the base project. Open VSdocman window and select Project Properties. Click the 'Copy' button on the left side and copy desired properties from the project to SOLUTION-WIDE PROPERTIES.
 7. FIX: F1 didn't work for constructors in VS 2010/2012/2013 help. Moreover, links pointing to external URLs (e.g. http) in VS 2012 and 2013 help didn't work.
 8. FIX: The <font> XML comment tag didn't change a text color in VS 2010/2012/2013 help.
 9. FIX: When the command line utility VSdocmanCmdLine.exe was executed with VS 2013 to compile a documentation for a project, then wrong project from the same solution could be compiled instead of the specified one. 
10. FIX: Occasional problems with class diagrams (warnings and diagrams not generated) when executing "Compile Solution to Single Documentation".
11. FIX: If a code member or a topic had a link with an empty cref attribute in its XML comment, then some other links in the comment could be generated as an empty text.
12. FIX: In website projects, sometimes the files in Project Properties - Code Members - Files were not grouped into folders.

In version 6.8

 1. CHANGE: Removed the following settings for modeless comment editor: "Tool window", "Dockable" and "Tabbed document window". They were redundant and the window can be customized directly in the IDE as other VS tool windows, e.g. Solution Explorer.
 2. FIX: When a C# interface or a structure had an attribute with text that contained ":" character, then inherited/implemented interfaces were listed incorrectly in the generated Syntax section. 
 3. FIX: When creating a new comment with 'Add XML Comment' or 'Comment Editor', a default comment was not inherited from an overridden/implemented member in a current project. The comment inheriting worked fine when the comment came from a referenced assembly (i.e. not from a project member) or when it was done automatically during documentation compilation.
 4. FIX: When modeless comment editor toolwindow was closed and the "Automatically apply changes ..." option was selected, the comment changes were not applied sometimes.
 5. FIX: When an URL in href attribute of <see> or <seealso> XML comment tag contained a space character, the space was removed in generated link.
 6. FIX: Sometimes, MS Word reported an error in generated docx file and you needed to repair it. This happened when: A) There was an image with the space character or any non-ASCII character in its filename. B) There were files in your "external files folder" that were not actually used.
 7. FIX: When some third-party designer was opened in VS (for example DevExpress XAF Model Editor), then when you tried to open VSdocman for the first time, the licensing error dialog appeared.

In version 6.7

 1. NEW: Added additional keyboard shortcuts for cut, copy and paste - Shift+Del, Ctrl+Ins and Shift+Ins in WYSIWYG comment editor.
 2. CHANGE: Improved Help&Manual output for the latest H&M versions (show TOC when particular topic is loaded with direct URL, fixed newlines in code examples).
 3. CHANGE: Improved performance of comment editing in some projects that reference many third-party assemblies.
 4. FIX: Sometimes, a missing comment was not inherited from overridden/implemented member in a referenced third-party assembly.
 5. FIX: When IE 10 or higher was installed, double/triple-click didn't select whole word/sentence in WYSIWYG comment editor. Moreover, the word selection is improved now, it works as in VS editor. A word can contain an underscore '_' character and it doesn't contain a trailing space.
 6. FIX: In very rare cases, when you clicked inside WYSIWYG comment editor, the caret was set to a wrong position.
 7. FIX: In WYSIWYG comment editor, when a text selection contained a text of various colors, it was impossible to change its properties, e.g. change it to a bulleted list.
 8. FIX: Application could crash when pasting a text copied from MS Word (and maybe some other applications too) into WYSIWYG comment editor.
 9. FIX: The language selected by a user in local HTML documentation was not retained in Chrome browser. Moreover, the default selected language is C# and not VB now. This can be changed in a generated config file.
10. FIX: In docx  output, multiple sub-classes were indented incorrectly in the Inheritance Hierarchy.
11. FIX: The Inheritance Hierarchy was not generated for some classes in some cases.

In version 6.6

 1. FIX: The WYSIWYG comment editor was incorrectly wrapping lines for C# and VB examples inside <code lang="C#"> and <code lang="VB"> comment tags. Only generic code inside <code> was handled correctly and it was not wrapped.
 2. FIX: Copy&paste in the WYSIWYG comment editor didn't work in Visual Studio 2013 running on 64-bit operating system.
 3. FIX: In the WYSIWYG comment editor, pasting of non-ASCII text (e.g. diacritics, Chinese, ...) in HTML format (e.g. copied from IE or from the editor) didn't work correctly. This only happened when VSdocman was running on .NET 4.5, that means in VS 2013, 2012 and possibly also in VS 2010.
 4. FIX: After generating the documentation in MS Help Viewer format (VS 2010-2013 help), the documentation was not automatically registered. The problem was only present in version 6.5.
 5. FIX: Handling of some generic types. If, for example, a class inherited from a constructed generic type whose type argument was also a generic type (e.g. class TestClass1<T> : List<List<T>>), the links in syntax section were generated incorrectly. If the type argument was not generic (e.g. class TestClass1<T> : List<T>), it worked OK.
 6. FIX: In the Inheritance Hierarchy, external superclasses (e.g. System.Object) were not shown correctly. This problem was present in versions 6.3 and higher.

In version 6.5

 1. NEW: Support for VS 2013 and VS 2013 help system.
 2. CHANGE: In chm_msdn10_lightweight and html_msdn10_lightweight output formats, the language tabs for unavailable languages in code examples are not visible anymore.
 3. FIX: Overloaded external methods (defined as extern in C# or as Declare in VB) were not shown correctly in generated documentation.

In version 6.4.4996

 1. FIX: In VS 2012 C# code, a link to a type in the same project/solution but in a different namespace wasn't correctly resolved because 'using' statements were ignored. This worked correctly in other versions of Visual Studio.

In version 6.4

 1. NEW: Automatically update content of the comment editor (opened as modeless window) as you go through your source code. You don't need to click on the editor to see the comments of the current code element. This may slow down the IDE. You can turn on or off this feature in Options > Comment Editor > Editor Window.
 2. NEW: Improved functionality of user tags. In addition to a tag name and its generated section heading, you can now define also a default text that will be placed in documentation if the tag in your XML comment is empty.
 3. CHANGE: When the cursor is inside XML doc comments, starting the comment editor or adding an XML comment will be executed for a code element to which the XML comment belongs, e.g. a method. Previously it was a containing parent type, such as a class or a namespace.
 4. CHANGE: If the summary section in the comment editor is empty, than an empty <summary></summary> comment block is not generated anymore.
 5. FIX: If method parameters were decorated with attributes, the attributes were not shown or the parameters were shown incorrectly in generated Syntax section.
 6. FIX: If you selected install for "Everyone" and not for "Just Me" during VSdocman installation, this option was ignored and VSdocman was installed just for current user. This caused problems especially for automated command line builds, because they are usually executed under different user. This issue was present only in versions 6.2 and 6.3.
 7. FIX: Sometimes, the WYSIWYG comment editor, when opened as modeless window, didn't show code element's comment and stayed empty.
 8. FIX: When the command line utility VSdocmanCmdLine.exe was stopped prematurely (with console close button, CTRL+C, process kill...), an orphaned devenv.exe process might be left unterminated.
 9. FIX: When generated HTML documentation was stored on a web server and it was viewed with Chrome, then the TOC was always collapsed when different topic was selected.

In version 6.3.4857

 1. FIX: When no C# or VB project was loaded or selected on the Solution Explorer, then starting VSdocman from the toolbar or Tools > VSdocman menu did nothing. Main VSdocman window that allows editing only global preferences should be opened. This problem only appeared in version 6.3.

In version 6.3

 1. NEW: Added new <br/> XML comment tag which lets you insert a newline. Unlike the <para> tag, it doesn't create a new paragraph. You can press SHIFT+ENTER in comment editor to insert this linebreak.
 2. NEW: Output messages and warnings during compilation are logged also in VS Output window and Error List (as clickable warnings). The same applies when compiling the documentation from command line, for example, in post-build event.
 3. NEW: Added the option not to sort See Also links. By default they are sorted alphabetically. You can now suppress it with setting in project properties, not accessible from GUI. Just open .vsdoc file for the project and change value of "VBdocman_dontSortSeeAlsoList" key from 0 to -1.
 4. CHANGE: New code files added to a project are automatically included for compilation even if VSdocman isn't launched when the files were added. And it automatically works for all profiles, not just the current one. This is caused by the fact that VSdocman now saves explicitly excluded files instead of included files. To apply this change, you need to re-save project properties. Just open VSdocman main window for a project (switch to each profile if any) and press OK.
 5. CHANGE: Better responsiveness for large web site (not web application) projects.
 6. CHANGE: In HTML output formats, the links to external URLs, defined with <see href=...>, will open in the top window instead of the right frame.
 7. FIX: Linked (included with Add as link) *.designer.cs/vb files were incorrectly listed in Project Properties - Code Members - Files.
 8. FIX: Sometimes, usually when IE 10 was installed, an existing link couldn't be edited in WYSIWYG comment editor.
 9. FIX: Adding a See Also link in WYSIWYG comment editor didn't work correctly. 

In version 6.2

 1. NEW: Added docx output file format. Now you can generate docx document in OOXML format compatible with MS Word 2007 and higher. You can later edit, print and convert it to PDF.
 2. CHANGE: Conditional compilation and regex filters are applied also to a list of members now. For example, if you override ToString method and exclude it from compilation with <compilewhen>never</compilewhen> the topic for that method will not be generated. But the inherited Object.ToString method was still listed in Members and Methods lists. This has now changed and the Object.ToString method isn't listed at all. The same applies to regex filters.
 3. FIX: In VB 2012, it is possible to omit the ByVal keyword for a parameter passed by value. VSdocman generated incorrect declaration as ByRef in that case.
 4. FIX: When compiling from command line with /operation compileSolutionToSingle, the compilation failed in the second pass. This problem only appeared in version 6.1.
 5. FIX: Comment editor inserted incorrect relative path to the XML file (one folder higher) in <include ...> comment tag.
 6. FIX: A dead link was generated if a <see> link to an enum was not specified with a full enum name (with the namespace).
 7. FIX: A random file named "NULL" could be created in the current directory when generating "MS Help Viewer" format.

In version 6.1
 1. NEW: You can switch edited or compiled project directly in the main VSdocman window. There's a new drop-down button next to the project name. You no longer need to close the window and switch the project in Solution explorer.
 2. NEW: Added new <threadsafety> XML comment tag which lets you describe thread safety of a class or structure.
 3. NEW: Added new <permission> XML comment tag which lets you document the access of a member.
 4. NEW: A search box at the top of "Select reference" dialog in comment editor. This allows for quick filtering in a class hierarchy.
 5. NEW: User gets a warning when the main window is cancelled and there are any unsaved changes.
 6. CHANGE: In topic titles and Index entries, the parameters of overloaded methods are displayed in a short form instead of a long form. For example, Method1(StringBuilder) instead of Method1(System.Text.StringBuilder).
 7. CHANGE: Changes to a project profile or preferences in VSdocman window are no longer automatically saved when you press any of the "Compile ..." buttons. You must explicitly press OK button when closing the window.
 8. CHANGE: Unused F# tabs are removed from syntax declaration and code examples in html_msdn10_lightweight and chm_msdn10_lightweight output formats.
 9. FIX: Overloaded methods with generic constructed types as parameters were not listed in generated TOC. They were only accessible from Index. For example: method1(List<int> x) and method1(List<string> x).
10. FIX: When you opened an existing XML comment with an image in comment editor, the image was not shown.
11. FIX: If a user selected a file in a sub-folder of "External files folder" with "Select reference" dialog in comment editor, generated relative path was incorrect.
12. FIX: In C#, if an XML comment or code element's attributes or element declaration itself was inside #if ... #endif, then the XML comment was not recognized.

In version 6.0
 1. NEW: Support for VS 2012 and VS 2012 help system.
 2. NEW: Significantly improved speed and memory consumption.
 3. NEW: Improved look and behavior of WYSIWYG comment editor. For example, user can select colors for highlighting of editable regions, paste or drag&drop formatted HTML text including images, drag&drop image files, select editor font size and more.
 4. NEW: Added href attribute to <see> and <seealso> comment tags. This attribute is used for referencing external file or URL and it replaces old cref="^..." syntax. The old syntax is still supported but the comment editor will produce the new href syntax, for example <see href="http://www.helixoft.com">Helixoft</see>. The new href syntax is easier to read and doesn't cause VS warnings.
 5. NEW: Added support for definition terms in comment editor and generated documentation. A definition term is represented by a <term> XML comment tag  inside a <list>  tag and it is visually highlighted in documentation.
 6. NEW: Added $INHERITED-COMMENT-MEMBER-CREF$ macro for comment templates. For currently edited code member, this macro returns cref of the member from which a comment can be inherited. It may be overridden or implemented method, property or event.
 7. NEW: A list of namespaces is automatically appended to the end of a custom topic which contains namespaces, i.e. it contains namespaces placeholder as a sub-topic.
 8. NEW: During compilation, VSdocman reports wrong XML comments, i.e. comments that are not well-formed XML.
 9. CHANGE: No more support for VS .NET 2002 and 2003. VSdocman now supports only VS 2005 and higher.
10. CHANGE: Removed old output templates for html, chm and help2 formats that had old VS 2002/2003 look. 
11. CHANGE: The main window and the "Select reference" dialog in comment editor are resizable now. 
12. CHANGE: The cref link to a type in the same project/solution but in different namespace doesn't have to be fully qualified anymore. VSdocman resolves the full name with using/Imports statements.
13. CHANGE: The comment editor produces short link syntax without the text if possible. For example <see cref="System.String"/> and not <see cref="System.String">String</see>.
14. CHANGE: No default comment (based on the comment templates used for commenting) is automatically added to non-commented code elements during compilation. This could cause incomplete text in documentation, for example unfinished "Gets or sets" phrase for properties. Inheriting of missing comments during compilation still works.
15. CHANGE: Each topic shows its own unique URL in a browser if you view HTML output formats. This makes it even easier to share the links to particular topics.
16. CHANGE: If you wish to distribute your documentation in MS Help Viewer format, you no longer need to edit a real path to helpcontentsetup.msha file in generated register_XY.bat script. The path will be retrieved automatically.
17. FIX: A link with Overload: or O: prefix in <seealso> tag pointed to a random overloaded method instead of Overloads page. This worked fine with <see> tag.
18. FIX: Links with constructed generic types didn't work, e.g. <see cref="List{String}"/>. Links with normal generic types worked fine, e.g. <see cref="List`1"/>.
19. FIX: Sometimes, the link to implemented or inherited interface or class was broken in Syntax section. This could happen if the target (implemented or inherited interface or class) was defined in the same project/solution but in different namespace. Or the target was an external type and VSdocman didn't resolve its full name because sometimes it failed to read the using/Imports statements.
20. FIX: In C#, if there were code elements with the same names but different case (e.g. method1 and Method1), only the first one was included in documentation.
21. FIX: If there was a file with a space in its name in external files folder (e.g. "my picture.png"), then compiling a CHM format produced HHC5003 error. The reason was that the space was incorrectly escaped by %20 sequence in generated HHP file.
22. FIX: If registration name contained Chinese or Arabic characters, the registration failed.
23. FIX: Compilation warnings were not displayed when executing VSdocman from command line with VSdocmanCmdLine.exe.
24. FIX: Very rarely, "The Visual Studio couldn't be found." error might appear when executing VSdocman from command line with VSdocmanCmdLine.exe.
25. FIX: Links in class diagrams didn't work in some recent versions of Firefox.

In version 5.5
 1. NEW: Support for dependency properties and attached properties. See the "Using VSdocman - Tips & Tricks - Documenting Attached Properties" topic in the help for more details.
 2. NEW: Support for optional parameters in C#.
 3. CHANGE: Links to external types (e.g. .NET types) no longer need to be fully qualified. So instead of <see cref="System.String" /> you can use <see cref="String" /> or language specific <see cref="string" />.
 4. CHANGE: Texts in JScript syntax sections are localized now, e.g. "JScript does not support generic types and methods.".
 5. CHANGE: Constants and variables are no longer separated but grouped together under the "Fields" section in generated TOC.
 6. CHANGE: When you edit an <include> comment tag in comment editor, the editor automatically includes also the code element's cref prefix (M:, T:, ...) in the path attribute, e.g. <include file="external_comments.xml" path="doc/members/member[@name='M:MyNamespace.MyMethod']/*" />.
 7. FIX: Overloaded Explicit and Implicit operators in C# 2008 and 2010 were incorrectly identified as Addition operator.
 8. FIX: Some problems if your VB code contained elements with names enclosed within [ and ]. This is the case if VB code element uses the same name as some VB keyword. For example, if you want a class named Error, you declare it as Class [Error].
 9. FIX: F1 help for some code elements didn't work in MS Help Viewer (VS 2010) help format.
10. FIX: Readonly fields were marked as constants in generated documentation.
11. FIX: The text in <seealso> tags was ignored if cref attribute pointed to an external file or URL using cref="^..." syntax. The cref attribute value was displayed instead.
12. FIX: The code elements of VB web site project (not web application) were not listed in generated TOC. They were only visible in Index.

In version 5.4
 1. FIX: Correct fonts and sizes according to system settings. Dialogs didn't look good especially on Windows XP with DPI other than default 96.
 2. FIX: An empty Source code section was generated for VB projects when "Remove line continuations from source code and join split lines" was selected even if source code inclusion was disabled.
 3. FIX: Random ghost ".vsdoc" files were created when VSdocman was started with no solution loaded in VS.
 4. FIX: In all html_* output formats, there were no generic parameters shown at class names in a table of contents.

In version 5.3
 1. NEW: Templates for generating HTML and CHM output which looks like the default online MSDN "lightweight" style.
 2. NEW: Option to delete all files in output folder before compilation. This can be set in Project Properties - Output - General.
 3. NEW: More details in generated documentation. The parameter type is listed also in its description, not only in syntax section. Added "Implements" section which lists implemented methods/properties.
 4. CHANGE: When you leave the "Platforms" property empty, then the Platforms section will not be shown in generated documentation at all.
 5. CHANGE: You no longer need to select also Constants if you want to include enumeration items in generated documentation.
 6. FIX: Sometimes there was an error when registering the help in MS Help 2 format (HxS files used in VS 2002-2008 help). This happened if a project or solution name contained a dot. Then the generated file names contained more than one dot. This is not allowed. The name is escaped now.
 7. FIX: The links that pointed to methods with generic parameters were broken in class diagrams.
 8. FIX: When generating "Pretty file names", the first link in Overload List was not working in HTML-based output formats.
 9. FIX: Broken formatting in Syntax section and source code listing in MS Help Viewer 1.0 format (VS 2010 help).
10. FIX: When you created or switched to a new profile and then edited any custom topic with WYSIWYG editor, then after pressing OK button, all changes in the new profile were saved into previous profile.

In version 5.2
 1. NEW: Missing XML comments are inherited also from implemented members, not only from overridden members.
 2. NEW: Added new <overloads> comment tag which allows to specify a summary, remarks and examples common to all overloads of a member. This information will appear on the Overloads topic page for the members.
 3. NEW: You can use the Overload: prefix in cref attribute of a link also for methods in current project. The link will point to overloads list page. Previously, this was only possible in links pointing to external methods (e.g. in .NET framework).
 4. NEW: You can use shorter O: prefix as an alternative to Overload: prefix in cref attribute of a link.
 5. NEW: Added Russian ru-RU localization.
 6. NEW: Added Thai th-TH localization.
 7. CHANGE: Improved listing of overloaded methods on Members page in MS Help Viewer format.
 8. CHANGE: By default, it's no longer possible to use macros from output templates directly in XML comments. Macros have the form: $MACRO-NAME$. If you wanted to use $ character, you had to escape it with $$. This is no longer necessary. If you still want to use macros in your comments, which is very unlikely, you can enable them manually in project properties. Just open .vsdoc file for the project and change value of "VBdocman_allowMacrosInComments" key from 0 to -1 (there is no GUI option).
 9. CHANGE: Significatly increased a speed of documentation compilation for large web site projects, when not all source code files are selected for compilation.
10. FIX: When an interface inherited from more than one base interface, then inherited members only from the first base interface were listed. Members from other base interfaces were ignored.
11. FIX: When a type implemented a generic interface, then its (and its members') syntax declaration was not generated correctly in some cases.
12. FIX: Sometimes there was an error when registering the help in MS Help Viewer format. One case was when the constants were included in a documentation. Another case was, if project or solution name contained a dot. Then the file name of generated OUTPUT_FILE.mshc file contained more than one dot. This is not allowed due to a limitation of MS Help Viewer 1.0 format. The name is escaped now.
13. FIX: The <see ...> links pointing to enumeration items caused "Not found" error. Since there is no separate help page for each enumeration item, such link is transformed to plain bold text now.
14. FIX: Some incomplete links in the form <see cref="Method(parameters)" /> pointing to method in current class didn't work.
15. FIX: Attributes of C# enum items were ignored (e.g. in regex filters).
16. FIX: Generating documentation for large web site project (not web application) in VS 2010 caused VSdocman crash.
17. FIX: In HTML and CHM documentation format, links to some classes (e.g. Hashtable) in web MSDN documentation didn't work.
18. FIX: Links to referenced external types that are not a part of .NET framework (e.g. third-party controls) are no longer generated. Only the plain text is generated now. This feature worked only for methods and properties, not for classes and interfaces. If you still want to generate the links, you can set it manually in project properties. Just open .vsdoc file for the project and change value of "VBdocman_linkForExternalNotInFramework" key from 0 to -1 (there is no GUI option).
19. FIX: When generating documentation in HTML format, some files contained the + character. This could cause problems on IIS7 web sites.
20. FIX: HelixoftHelpReg.exe and HelixoftHelpRegQ.exe utility didn't register F1 help in CHM format for VS 2008. Other help formats and other VS versions worked fine.

In version 5.1
 1. NEW: VSdocman now fully supports new MS Help Viewer format used in VS 2010 help.
 2. NEW: You can use path macros such as $(ProjectDir), $(SolutionDir) and $(VSdocmanDir) for specifying output folder, external files folder and templates folder. For example you can define output folder as $(ProjectDir)..\..\VSdoc. This is useful when sharing .vsdoc project properties in source control system.
 3. CHANGE: Improved handling of operators. Operators are now listed separately, they have correct syntax in all languages, they use correct cref syntax in links and their pretty file names don't contain forbidden characters.
 4. CHANGE: Improved saving of a project properties (.vsdoc) file. If the file is under source code control, it is first checked out before saving. The file is now saved less often, only when really necessary. Now, the settings in this file are not ordered randomly so the source code control isn't confused. Moreover, the properties are saved in more readable format for easier conflict resolving with source code control.
 5. CHANGE: When you add a new file into C# project, the file is automatically added to the list of files to be compiled.
 6. FIX: VB 2010 introduced implicit line continuation, i.e. in many cases, you can continue a statement on the next consecutive line without using the underscore character " _". Sometimes, VSdocman failed to recognize or insert XML comments in these cases.
 7. FIX: When the "Compile Solution to Single Documentation" was used, only the regex filters from a base project were applied to all projects. Regex filters from individual projects were ignored.
 8. FIX: When you defined your own additional namespace placeholders in custom topics then a "ghost" "New Topic" was generated in documentation TOC.
 9. FIX: Class diagram was not generated if it was not updated according to actual source code. For example the diagram contained a deleted class. Now the diagram is generated and a compilation warning is displayed.
10. FIX: When using the <include> tag in custom topics, the <summary> part was not included from external XML file.
11. FIX: Compiling from command line with "compileProject" operation failed if the project was nested in a solution folder in its solution.
12. FIX: When the "Compile Solution to Single Documentation" was used with RTF output, there were no code members present in a documentation.
13. FIX: When you added a new file into VB project, the list of files to be compiled was cleared.
14. FIX: Once you loaded a solution with only one project, the "Compile Solution to Single Documentation" and "Compile Projects in Solution Separately" buttons stayed disabled forever. Even when you later opened solution with more projects. You needed to restart Visual Studio and open the multi-project solution.

In version 5.0
 1. NEW: Added support for Visual Studio 2010.
 2. NEW: Added Hebrew he-IL localization and right to left text direction support.
 3. NEW: Added Georgian ka-GE localization.
 4. NEW: Regex filters allow to search also in member XML comments.
 5. NEW: You can use new $CURSOR$ macro in comment templates. This macro specifies where the cursor will be positioned after inserting XML comment using "Add XML comment" function.
 6. NEW: Comment templates also for parameters. For example, the following sentence is generated for parameter of EventArgs type: "An EventArgs that contains the event data.". Due to these new commenting features you should update you preferences (you can use "Reset" button to get default templates with all new features).
 7. NEW: Extension methods are listed also on Members and Methods pages for types on which extension methods operate. This works for your own extension methods and also referenced (e.g. LINQ) methods. For example, if your class implements IEnumerable(T) interface, methods such as GroupBy, OrderBy, Average, and so on will be listed on its Members and Methods page.
 8. NEW: HelixoftHelpReg.exe utility accepts new -z argument now. When this argument is used, the utility always returns 0 (OK) as exit code, even if there was an error during execution. This is useful if you include HelixoftHelpReg.exe as custom action in your MSI package and you don't want to cancel whole installation if there is some problem with help registration. MSI automatically fails if custom action returns non-zero value. 
 9. NEW: The $MEMBER-ASSEMBLY-VERSION$ macro which shows version number of documented assembly. You can use it anywhere in your comments, templates, footer or custom topics.
10. CHANGE: Improved resolving of incomplete links. For example it is no longer necessary to prepend dot in <see cref=".prop1" /> link pointing to prop1 property in current class. Instead you can use just <see cref="prop1" />.
11. CHANGE: Links to referenced external members that are not part of .NET framework (e.g. third-party controls) are no longer generated. Only the plain text is generated now. It's because there was only small chance that such help topic existed and these links caused "not found" error. If you still want to generate the links, you can set it manually in project properties. Just open .vsdoc file for the project and change value of "VBdocman_linkForExternalNotInFramework" key from 0 to -1 (there is no GUI option).
12. FIX: When targeting .NET framework 3.0 and higher, the XML comments from framework members were not always inherited correctly.
13. FIX: Links to generic members and to methods without parameters were broken in generated class diagrams.
14. FIX: Links to online MSDN help didn't work for some members (e.g.  System.Collections.Generic.LinkedList(T)) in generated html_msdn2 output.
15. FIX: In html_msdn2 output, if there was inline link to external URL, there were no scrollbars when external document was displayed.
16. FIX: WYSIWYG comment editor produced wrong cref links to methods whose parameters were constructed generic types, e.g. MyMethod(T).
17. FIX: WYSIWYG comment editor produced wrong comments on some rare occasions - if there were blank lines inside <code>, bulleted or numbered lists contained only one item and others.
18. FIX: Changes in comments in external XML comment files included with <include> tag were not updated in generated documentation. Restart of VS was needed.

In version 4.4.3586
 1. FIX: WYSIWYG comment editor escaped some characters in relative paths for local class diagrams and images. For example, the escape sequence %20 instead of space in class diagram path caused diagram loading error.

In version 4.4.3572
 1. FIX: WYSIWYG comment editor incorrectly inserted forwards slash instead of backward slash as path delimiter in relative paths for class diagrams and images. The forward slash in class diagram path caused diagram loading error.
 
In version 4.4
 1. NEW: You can include clickable class diagrams in documentation. Create nice diagrams and insert them with <img> XML comment tag. The comment editor  fully supports this feature. Class diagrams are only available in VS 2005 and higher.
 2. NEW: You can define unlimited number of user tags for your own sections in documentation. Previously it was possible to define only 5 user tags.
 3. NEW: You can create a table with more than 2 columns also directly in comment editor. In previous versions, you could edit and use such tables in editor but you needed to create them manually with the <list> tag. 
 4. NEW: Added Chinese localization for generated output.
 5. NEW: Improved HTML output. You can now open particular topic directly. When you enter URL of some topic in the browser, the complete help with table of contents will be shown automatically. This way it is easy to send URL of particular topic to your customers or coworkers. To get URL of the topic, just right-click on the topic in TOC and select "Copy link" from browser context menu.
 6. NEW: Improved HTML output. The table of contents is automatically synchronized with topic open in right frame.
 7. NEW: The type name XYZ in text "(Inherited from XYZ.)" on members page is clickable link now.
 8. FIX: Opening comment editor with XML comment containing the <img> tag caused freezing of Visual Studio on Windows Vista. Initial insertion of picture worked well, however.
 9. FIX: The "Auto-find" button for searching the hxcomp.exe didn't work in VS 2008 with VS 2008 SDK installed.
10. FIX: Some <see> links to custom non-API topics were not working in HTML documentation.
11. FIX: There was no footer text in generated topics with enumerations.
12. FIX: WYSIWYG comment editor didn't work if the documentation title for the project contained backslash character. This happened for web sites (not web applications)  by default because there was web site folder path in the title.

In version 4.3
 1. NEW: Added support for custom topics. Using WYSIWYG editor, you can now create any number of custom topics such as overview, examples, license agreement, usage descriptions, etc. You can define your own structure of table of contents (TOC) with topics and chapters. You can place generated API documentation anywhere in the TOC. You can even split API reference and insert specified namespaces at various places. This makes VSdocman really powerful tool for creating complete end-user documentation for your libraries and applications.
 2. NEW: Automatic and manual checking for VSdocman updates.
 3. CHANGE: You can use XML comment tags (e.g. <see>, <b>, etc.) in the topic footer text.
 4. CHANGE: Cosmetic change in options GUI. Renamed "Compile" section in project properties to "Code Members" and "Members" to "Member Types".
 5. CHANGE: In RTF documentation, the links to framework classes point to the latest online MSDN instead of the old one.
 6. FIX: The files from external files folder (e.g. pictures) were not included in documentation. This bug only appeared in version 4.2.
 7. FIX: VSdocman preferences were lost in VS 2002 and VS 2003. This bug only appeared in versions 4.x.
 8. FIX: Don't show Void as return type for constructors in C# and C++ syntax.
 9. FIX: In some cases, the link edited with Reference dialog was updated incorrectly in WYSIWYG comment editor.
10. FIX: WYSIWYG comment editor didn't correctly show tables with more than 30 rows and 3 columns. Now it can handle tables with up to 100 rows and 30 columns.

In version 4.2
 1. NEW: You can create tables with more than two columns.
 2. NEW: Comment editor recognizes and converts the following HTML elements in XML comments: <strong>, <em>, <a href=...>, <a name=...>, <see href=...>, <p>, <br/>, <ul>, <ol>, <li>, <table>, <tbody>, <th>, <tr>, <td> and <pre>. So you can use HTML code in your XML comments and when you open comment editor, it will be automatically converted to XML syntax.
 3. CHANGE: WYSIWYG comment editor no longer removes top-level XML comment tags that are not supported or explicitly defined by user in options. This way you can add any number of your own top-level XML tags manually without being worry that editor will delete them.
 4. CHANGE: WYSIWYG comment editor no longer removes <see> tags without the text, e.g. <see cref="T:MyNamespace.MyClass" />
 5. FIX: VSdocman crash when documenting generic VB method whose type argument is array, e.g. Function MyFunction() As Dictionary(Of String, Byte()).
 6. FIX: No syntax declaration was generated for C# methods without parameters. This bug was introduced in version 4.1.
 7. FIX: Inactive links were generated for <see> tags with incomplete cref attribute (e.g. only class name without namespace and T: prefix) in <summary> section. It worked fine in other sections such as <remarks>.
 8. FIX: Error with missing pubsinterface.gif file in Help & Manual output.
 9. FIX: Error message when clicking the Constructors link in members page header in *_msdn2 formats.
10. FIX: Incorrectly formatted text in clipboard after using Copy Code in help2_msdn2 output.
11. FIX: Freeze during compilation on Windows 7 beta.

In version 4.1
 1. NEW: Added regex filters that allow include or exclude members from documentation according to their name, declaration and attributes.
 2. NEW: Added support for the following XML comment tags:
    <paramref>,
    <typeparamref>,
    <see langword="null"/>,
    <see langword="true"/>,
    <see langword="false"/>,
    <see langword="static"/>,
    <see langword="abstract"/>,
    <see langword="sealed"/>,
    <see langword="virtual"/>.
    These tags allow formatting of parameter references and language keywords. It is recommended that you update your XML comment templates in VSdocman options if you update from version 4.0. You can do it with Reset button or manually (change e.g. <b>true</b> to <see langword="true"/>).
 3. NEW: Added instant regex tester in comment rules editor.
 4. FIX: Incorrectly generated syntax declaration for extension methods.
 5. FIX: Sometimes, VSdocman froze on multiple screen systems. This happened when some of VSdocman windows was open on secondary screen. Its position was saved and the next time when secondary screen was not turned on, modal window was not visible and it looked like VSdocman was frozen.
 6. FIX: Compilation of documentation crashed with "Unspecified error" when there was no member selected for compilation, e.g. no source code file was selected in Compile - Files properties.

In version 4.0
 1. NEW: Completely reorganized main window with new fresh look. Settings that are common to all projects were moved from project properties to global options. 
 2. NEW: Improved WYSIWYG comment editor - new look, nicer highlighting of editable sections, TAB key is used to move between editable sections, improved selecting, deleting and pasting of text blocks. 
 3. NEW: Flexible and intelligent templates for inserting XML comments. There are predefined rules which automatically fill <summary> and other values with standard text. For example, the following sentence is generated for constructor: "Initializes a new instance of the <CLASS-NAME-AND-LINK> class". You can define any number of your own rules. Moreover, when inserting comment, VSdocman can inherit comment from overridden member.
 4. NEW: Added Help & Manual output format. VSdocman supports complete integration with Help & Manual now. It is possible to create any TOC structure and additional non-API topics such as overview, license info, use cases, etc. Moreover, with H&M you can generate some other output formats, e.g. PDF.
 5. NEW: In addition to inherited members from project/solution, also inherited members from .NET framework classes are shown in Members list. For example, ToString, GetType and other methods are automatically listed. This is especially useful for documenting user controls where all inherited properties, methods and events are listed. 
 6. NEW: Missing XML comments in overridden members are automatically inherited also from .NET framework classes, not only from project classes. For example, if your class inherits from System.Object and it overrides ToString() method and it has no XML comments, then comments from System.Object are automatically used. 
 7. NEW: You can set your own documentation title. It is used in help window title, TOC, topic headers, etc. 
 8. NEW: You can set language for code examples with lang attribute. You can use <code lang="C#"> and <code lang="VB">. 
 9. NEW: You can set sort order for enumeration items - by name, by value or unsorted. 
10. NEW: Added <include> comment tag which allows referencing XML comments in external files. 
11. NEW: Highlighted code syntax in chm_msdn2, html_msdn2 and help_msdn2 otput formats. 
12. CHANGE: Significantly improved chm_msdn2 and html_msdn2 output - new look of the latest MSDN, language filter with persisted language settings. Moreover, the links to framework members are always working in chm_msdn2 output. Depending on installed MSDN version on end user's computer, the links point either to the latest local MSDN or online MSDN. 
13. CHANGE: Title page text can be formatted with XML documentation tags such as <para>, <b>, <img>, etc. 
14. CHANGE: The XML documentation file is generated also for Web Site projects. 
15. FIX: The "List inherited members" option on Compile - Members page was not saved. 
16. FIX: No more "Dead link..." warnings when <see> or <seealso> tags pointed to .NET framework members. 
17. FIX: Incorrect displaying of national (e.g. Russian) characters in Index and Search results in CHM outputs. 

In version 3.5
 1. NEW: Enum items can be sorted by name, value or unsorted. (No GUI option yet. You need to manually edit .vsdoc file.)
 2. CHANGE: The comment editor generates the top level XML comment tags - <summary>, <remarks>, <returns>, <value> and <example> on separate lines instead of on one line.
 3. CHANGE: When reading top level XML comment tags (e.g. <summary> or <remarks>), all leading and trailing whitespaces in tag value are ignored now.
 4. CHANGE: Member chapters in RTF output have different styles now (Heading 1-4). This allows better customization, e.g. numbering, custom structured TOC, etc.
 5. FIX: VSdocman wasn't present in VS 2008 sometimes if both VS 2005 and VS 2008 were installed.
 6. FIX: The help2_msdn2 output works with both VS 2005 and VS 2008 MSDN now.
 7. FIX: When generating documentation using "Compile Solution to Single Documentation", some projects didn't appear in the table of contents. They were only visible in Index.
 8. FIX: In Web Site projects (not Web Application projects), there was no syntax section generated for methods.
 9. FIX: In Web Site projects (not Web Application projects), compilation was aborted with "Unspecified error" if project contained overloaded methods.
10. FIX: In Web Site projects (not Web Application projects), also aspx files appeared randomly in the files list in Compile - Files options.
11. FIX: Sometimes, "Error reading file." error occurred in command line compilation and compilation didn't finish.
12. FIX: In VB 2005, not all overloaded properties were included in documentation. 
13. FIX: Comment editor inserted <returns> instead of <value> tag for properties.
14. FIX: Pictures included with <img> tag were not visible in RTF output.
15. FIX: The WYSIWYG comment editor appended random character to each picture, if that picture was followed by character other than white-space.
16. FIX: Occasional crash during compilation, especially with large solutions.

In version 3.4.2970
 1. NEW: The "Select link" dialog in comment editor allows selecting the members in referenced libraries (e.g. .NET classes) also in VS .NET 2002 and 2003. 
 2. CHANGE: The "ParamArray, comma-delimited list of values." text is no longer automatically prepended to description of parameters defined with ParamArray in VB or params in C#.  
 3. CHANGE: The "Optional", "Required" and "The default value is " texts are automatically prepended to optional parameter description only when parameter description is empty. (VB only). 
 4. CHANGE: The links to referenced members that are not part of .NET framework (e.g. third-party controls) are correctly generated too. There's a chance that the target help topic will be found.
 5. FIX: Inserting images in comment editor didn't work on Windows Vista.
 6. FIX: Sometimes, the command line build exited with error code 3 without generating documentation.  
 7. FIX: Comment editor generates correct cref link for generic constructed types and for arguments whose types are type parameters. The same applies to generated XML doc file. For example a method with full name
    Class1<T1, T2>.Method1<T3>(List<int> x, T2 y, T3 z) in C# or
    Class1(Of T1, T2).Method1(Of T3)(ByVal x As List(Of Integer), ByVal y As T2, ByVal z As T3) in VB
    should have the following cref link:
    M:Class1`2.Method1`1(System.Collections.Generic.List{System.Int32},`1,``0). 
 8. FIX: Methods in C# with no comment didn't inherit comment from overridden method. 
 9. FIX: The member's parent class name was not listed in See Also section of documentation generated with VS .NET 2002/2003. 
10. FIX: Wrong resizing of compilation progress dialog. 

In version 3.4.2942
 1. CHANGE: In Compile - Files options, the files are now shown as a tree for better navigation.You can easily select/deselect  whole folder now.
 2. FIX: New solution or project profile couldn't be created. This problem appeared only in version 3.4.
 3. FIX: Wrong indexing of the title page for full-text search in HTML output format.

In version 3.4
 1. NEW: Visual Studio 2008 support. 
 2. NEW: Added full-text search functionality in HTML output.  Moreover, table of contents and index are no longer implemented as Java applets. Everything is implemented in HTML and JavaScript.  This resolves security problems on intranets, various Java related issues and better indexing by search engines. 
 3. NEW: The "Select link" dialog in comment editor allows selecting also the members in referenced libraries (e.g. .NET classes) in VS 2005 and higher.
 4. CHANGE: Compiling  web site and web application projects is faster. 
 5. CHANGE: The compilation window is more responsive. You can cancel  the compilation immediately at any time. 
 6. CHANGE: The "Optional", "Required" and "The default value is " texts are automatically prepended to parameter description only when there is at least one optional parameter (it happens in VB only). Moreover, these texts are localized now. 
 7. CHANGE: Removed "Members" sub-page under namespaces in TOC. This page is not needed because all namespace members are listed on namespace main page. 
 8. CHANGE: Empty namespaces are not included in documentation. 
 9. FIX: Passing "/vs 2005" parameter to VSdocmanCmdLine.exe caused an error message. 
10. FIX: Using "/compileProject" operation in VSdocmanCmdLine.exe sometimes processed random project from the solution instead of specified project. 
11. FIX: The Help2 documentation was not registered correctly on some computers. There was no table of contents shown for generated documentation, only Index and Search worked fine. 
12. FIX: Small problems in WYSIWYG comment editor - multiple lines with formatting (e.g. bold) inside <code> tags were joined together when opened in editor again, incorrect selecting/unselecting text with Shift + down arrow, improved undo operation. 
13. FIX: When declaring some member as generic type with particular type argument, the declaration in the help didn't contain two links - one to generic type and one to type argument. For example "public ICollection<MyClass> test;" in C# or "Public test as  ICollection(Of MyClass)" in VB should contain links to ICollection and to MyClass. 
14. FIX: Complex constant and enum values in C# (hex, containing +-/* or comment) are now calculated and correctly shown in all language syntax sections. 
15. FIX: Wrong syntax was generated for classes that inherited from generic classes in C#, e.g. public class MyClass : List<int>. 
16. FIX: Wrong syntax was generated for properties with different accessibilities for getter and setter part (.NET 2.0 and higher). 
17. FIX: Compiling large web site or web application projects (more than 1000 code files) caused VS crash. 

In version 3.3
 1. NEW: Added profiles. You can now save your settings under�custom profiles and easily generate�different documentation for the same project. You can also exclude specific projects when compiling documentation for whole solution. 
 2. NEW: Added pt-Pt (Portuguese) output localization. 
 3. CHANGE: Enhanced command line functionality. The VS IDE is no longer shown, the messages are written directly to console standard output and added support for profiles. 
 4. CHANGE: Removed Save/Load default settings functionality. 
 5. CHANGE: Modified help2_msdn2, html_msdn2, chm_msdn2 and rtf outputs. When compiling the solution to single documentation, the help title, header and file names are based on solution name and not on the current project name. Moreover, the Help2 output no longer contains unnecessary extra root node. 
 6. CHANGE: Launching of VSdocman on web projects in VS 2005 works much faster now. 
 7. FIX: When "Public" was not selected for compilation in VSdocman options, explicitly defined namespaces and their contents were not included in documentation. 
 8. FIX: In web site projects in VS 2005, the source files in subfolders were ignored. 
 9. FIX: In Web Application projects in VS 2005 (not web sites), the code behind files of the forms were ignored. 
10. FIX: If the solution contained SQL Server 2000 Reporting Services project, the "Compile Solution" and "Compile Solution to One Documentation " buttons were not available. 
11. FIX: When Pretty file names�were selected in Output - File Names options, constructors were not listed in documentation. 
12. FIX: The C# source code is no longer marked as Visual Basic in some output formats. The language of the source code is shown correctly for VB .NET and C#. 
13. FIX: The blank lines�in source code and code examples were removed in HTML based documentation. 
14. FIX: The user defined Platforms text was ignored in some output formats. 
15. FIX: The "Copy Code" button above the code section is fixed in chm_msdn2 and html_msdn2 output. 
16. FIX: The inheritance tree was not shown for some classes and some links to framework classes didn't work as well. 
17. FIX: The class declaration was handled incorrectly if it contained conditional compilation directives (e.g. #if). 
18. FIX: Sometimes the comment editor (when set as modal) was hidden behind VS window. 
19. FIX: In comment editor, when�the last text in table cell was code or link, the XML comment for the table was generated incorrectly.�
20. FIX: Installation error on Windows Vista.

In version 3.2
 1. NEW: You can select for which languages VSdocman generates syntax - VB .NET, C#, C++ and JScript. 
 2. NEW: You can define platforms and supported frameworks.
 3. NEW: User is warned if he tries to insert picture from outside of external files folder or if external files folder is not defined.
 4. CHANGE: Adding or editing XML comments in large files works faster now. 
 5. CHANGE: Main VSdocman window stays open for further work after compiling documentation. 
 6. CHANGE: Improved RTF output. Added page numbers in TOC and index. Removed duplicate namespaces when compiling solution to single documentation. 
 7. CHANGE: Generated help page for the namespace doesn't contain declaration section anymore. 
 8. FIX: Sometimes the "Select reference" dialog didn't show all namespaces in the project. 
 9. FIX: When using help2_msdn2 output format, the topics were shown incorrectly if MSDN for VS2005 was uninstalled (replaced by full MSDN). 
10. FIX: VSdocman locked if there were /* ... */ comments inside attribute. 
11. FIX: In VS 2005, when documenting whole solution, the projects in solution folders were not included. 
12. FIX: In some rare cases, the "Dead link..." warnings appeared when there were no dead links at all. 
13. FIX: No "S" icon in class list and no "static" keyword in C# declaration for C# static classes in VS 2005. 
14. FIX: There was no link to parent class in See Also section of class members if the class was generic and written in C#. 
15. FIX: Wrong syntax of array parameters in C# methods was used in VB .NET declaration. The [] was used instead of ().
16. FIX: Namespaces were sometimes listed with full name and sometimes with short name. They are always listed with full name now.

In version 3.1
 1. Comment editor doesn't make word wrapping of the text inside <code> and <c> tags when writing comments back to source code. 
 2. Warning is shown when VSdocman cannot save its settings due to insufficient write permissions or file is read-only (because it is checked-in to SourceSafe). 
 3. FIX: Problems with generating the output for C# projects with generic members. The < and > characters in member name caused problems in HTML or XML based output formats. 
 4. FIX: Pasting of formatted text didn't work in WYSIWYG comment editor in VS 2005. 
 5. FIX: In some special cases, the XML comment was placed at incorrect place in C# source code in VS 2005. 
 6. FIX: Wrong section name for method return value in RTF output. 

In version 3.0 (VBdocman .NET renamed to VSdocman)
 1. Added full C# support. The program now supports VB .NET and C#. That's why it is renamed from VBdocman .NET to VSdocman. 
 2. Localized output in several languages including English, German, French, Spanish and Slovak. Adding new language is just matter of editing one text file. 
 3. All links (<see>, <seealso>, inheritance tree, types in declaration) can point to framework members now. 
 4. Member declaration is shown also in C#, C++ and JScript syntax and types inside are shown as links.
 5. Added ability not to list member attributes in declaration syntax section (Miscellanous - Source Code settings). 
 6. Inheritance tree shows all superclasses, even those outside the project, e.g. framework classes. 
 7. Public variables in the class are no longer listed as properties. They are listed as fields now. 
 8. Members on "Members" page are grouped and marked by accesibility (public, protected, ...). Static members have "static" icon. 
 9. Improved HTML output for even better cross-browser compatibility. 
10. Significantly improved performance speed. 
11. FIX: Comment editor was not displayed on computers with "Large Fonts" set. 
12. FIX: Problems with compilation of Declares in VS 2005. 
13. FIX: Problems with compilation of Events in VS 2005 
14. FIX: Problems in WYSIWYG comment editor: pasting multiple times, deleting text selection deleted also next character, inserting new section (e.g. Example) while text block was selected. 
15. FIX: Problems with remembering which files go to compilation. 
16. FIX: Incorrect values of enumeration constants that were not explicitly initialized. 

In version 2.3
 1. Added support for generics in VS 2005. New <typeparam> tag introduced.
 2. Improved support for partial classes and structures in VS 2005.
 3. Added support for <System.ComponentModel.Description...> attribute. You can easily insert <Description...> attribute from context menu. If you add new comment, default summary is automatically extracted from <Description...> attribute if any. 
 4. Comment editor now remembers whether it is in WYSIWYG mode and its size and position. 
 5. Removed editing of parameter settings from comment editor because parameter settings represent old practice from VB6 and you should use enumerations instead. VBdocman however still recognizes <set> and @set tags in the comments. 
 6. FIX: <returns> tag is not added by "Add XML Comment" for Subs. 
 7. FIX: VBdocman didn't work with Web projects in VS 2005.
 8. FIX: When using Compile Solution or Compile Solution to One Documentation, some projects may have empty documentation. 
 9. FIX: Compiling help for Smart Device projects didn't work. 
10. FIX: Command "VBdocmanNET.Connect.CompileSolutionToOne" didn't work from command line. 
11. FIX: Wrong adding and reading of comments in VS 2005 when member has attribute. 

In version 2.2
 1. Added support for VS 2005. Generics are not supported yet.
 2. Added support for smart device projects.
 3. VBdocman now produces and recognizes C# XML links in cref attributes. Type character is prefixed, e.g. M: or T:, [] are used instead of () for array parameters, @ is appended to ByRef parameters and there are no spaces between parameters. This is needed for good compatibility with VS 2005.
 4. Help 2 documentation can be viewed with full formatting immediately after generation.
 5. Context menus are only visible on VB and macro files.
 6. "Compile to One Solution" button is disabled when there's only one project in the solution.
 7. FIXED: When there was an option checked to generate IntelliSense XML file, some formatting tags (<c>, <see>, ...) in <summary> and <param> tags were ignored in resulting documentation.
 8. FIXED: Problem with the tabs (scrolling) in Comment Editor. 

In version 2.1
 1. Fixed bug that caused problems with setting a list of .vb files that are to be documented. This problem especially occured when updating your project from VBdocman .NET version 1.x to version 2.0.

In version 2.0
 1. New formatting and objects added to comments - bold, italic, underline, text color, links, bulleted or numbered lists, tables and pictures.
 2. Support for more XML documentation tags added - <list>, <para>, <see> and <value>.
 3. Comment editor is WYSIWYG. Only XML comments are generated by editor but VBdocman still recognizes also @-style comments.
 4. Comment editor can be also modeless, floating and dockable.
 5. <value> tag replaces <returns> tag in properties. <returns> tag is still valid in property.
 6. You can specify folder with your own external files now. All external files will be automatically included in documentation and you can reference them from your comments e.g. in <see> or <img> tags. 
 7. Added possibility to comment root namespace. 
 8. In addition to random numeric names, generated files can have also pretty and constant names based on member name. So you can easily reference them from outside. 
 9. You can generate ONE documentation for whole solution . Namespaces and members are merged into one TOC. 
 10. You can assign keyboard shortcuts to VBdocman actions.
 11. Preview of Help 2 documentation can be seen immediately after it is generated, without restarting VS. 
 12. VBdocman project settings are stored in separate .vbdoc file instead of .vbproj file. This avoids conflicts when using version control systems (SourceSafe) or automated builds. Old settings stored in .vbproj files are still valid if no .vbdoc file exists. 
 13. Documentation now indicates if a member has ObsoleteAttribute or FlagsAttribute applied. 
 14. Newly added project item is automatically included in VBdocman's Compile | Files list. 
 15. Undo operation after inserting comment by comment editor is improved. You don't need to perform Undo several times to get original state. 
 16. Inheriting of XML comments is fixed. 
 17. Paths (e.g. output path) may contain foreign non-English characters now. 
 18. Fixed problem with attributes in declarations on overloads list page. 
 19. Problem with saving of title text. Newlines were removed from title text after reloading VS. Fixed. 
 20. Missing spaces between words in RTF output when comment is on multiple lines. Fixed. 
 21. Fixed commenting of namespaces when one namespace was specified in multiple files. Now you only need to comment the namespace in one file. 


In version 1.3
 1. Fixed problems with links to external files. There is new prefix ^ for link to external files
    in addition to " prefix. 

In version 1.2
 1. Command line functionality added.
 2. Conditional compilation of individual members added. You can select for each member if it will be compiled.
 3. HTML output has now modern look, fixed scroll bars in table of contents and pages have MSDN style also in
    non IE browsers.
 4. References in XML comments that were broken to several lines are processed correctly now.
 5. Comment editor doesn't wrap references in @-style comments so that they be processes correctly.
 6. Fixed some problems when editing parameter settings in comment editor.
 7. Fixed parsing of constant value in @set tag if it was string with spaces.
 8. Fixed parsing of references in @-style comments if references contain spaces (functions with several
    parameters delimited with comma and space).
 9. Fixed functionality of "Find interesting links" button in comment editor in VS .NET 2003.
 10. @includesource tag always returned non empty value even if there was no value. Fixed.

In version 1.1.1495
 1. Auto-find button added to atomatically find hxcomp.exe anytime.
 2. Fixed problem when not all source files in the project were recognized. This happened when they had same names but were in different folders.

In version 1.1
 1. Non-english character sets supported.
 2. Non-english Visual Studio .NET supported.
 3. Ability to remove line continuations in source code listings in documentation.
 4. Compilation progress dialog can be resized to better reading of messages.
 5. Some macros added to templates to allow translation of templates to other languages.
 6. Some problems with unrecognized comments fixed.
 7. Behavior of Apply button in Comment Editor fixed.
 8. $CHRn$ macro processing fixed.
 9. When using XML comments, <, >, &, ' and " characters are escaped automatically in the background within $CODE$ block.
 10. Processing of names of overloaded members is not case-sensitive now.
 11. Fixed problems with enumeration constants in VS 2003.


8. CONTACT

Home page and registration information: http://www.helixoft.com

HELIXOFT
Tomasikova 14
080 01 Presov
Slovak Republic


Contact person:
Peter Macej
peter@helixoft.com